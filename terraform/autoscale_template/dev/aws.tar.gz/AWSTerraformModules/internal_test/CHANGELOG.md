## Build 0072
Improvements:
* Support customize health check options for AWS GWLB target group; 
* Fix login issue of FortiGate instance in lambda function;
* Improve log infomation;
* Improve update FortiFlex SN list on DynamoDB function to avoid lost SN track;

Changes:
* Add option of asg_health_check_grace_period on variable asgs for ASG examples;
* Add varaibla gwlb_health_check on all ASG examples;
* Add option of matcher on variable health_check of module aws.gwlb;
* Add variables of health_check_port and health_check_protocol on module fortigate.fgt_asg;

## Build 0071
Improvements:
* Fix index range issue when subnet_id_map is empty on module fgt_asg;
* Add functionality of association status of subnets of modules vpc_route_table;
* Add output of security_route_table for ASG examples;
* Support existing route tables for security VPC;

Changes:
* Add option of existing_rts for ASG examples;

## Build 0063
Improvements:
* Fix lambda invoke function timeout issue;

## Build 0062
Improvements:
* Fix index out of range issue of lambda function;
* Support existing route table on spk_vpc;

Changes:
* Add option of existing_rt on variable spk_vpc for examples;

## Build 0061
Improvements:
* Fix issue of index errors for do_terminate function when the instance been terminated without send terminate event to lambda function;
* Update select interface logic for FortiGate auto-scaling sync port;
* Implement FMG integration only with primary FGT instance;

Changes:
* Add option of primary_only on variable fmg_integration;

## Build 0055
Improvements:
* Change CHANGELOG.md;
* Upgrade lambda function environment from Python 3.8 to Python 3.12;
* Add depend_on to the resource aws_dynamodb_table_item;

## Build 0054
Improvements:
* Fix issue of ConditionalCheckFailedException caused by creating DynamoDB item;
* Support metadata options for instance template;

Changes:
* Add option of metadata_options for module fgt_asg;
* Add option of metadata_options on variable asgs of ASG related examples;

## Build 0053
Improvements:
* Fix issue of port number mismatch on fgt-userdata.tftpl;
* Move user_conf to DynamoDB table to avoid Lambda function environment variable exceed 4kb limitation;
* Explicitly create Cloudwatch log group by Terraform, so that Terraform will destroy the log groups when destroying the project;

## Build 0052
Improvements:
* Modify structure of variable of fmg_integration;

Changes:
* Add option of vrf_select on variable fmg_integration;
* Add option of ums on variable fmg_integration and put ums related variables into this block;

## Build 0051
Improvements:
* Support FortiManager integration as native mode; 
* Fix register device not work issue on ums mode;

Changes:
* Add option cloud_mode on variable fmg_integration;
* Add option api_key on variable fmg_integration;

## Build 0046
Improvements:
* Fix fgt_standalone FortiFlex token not work issue;

## Build 0044
Improvements:
* Add variable fgt_config_shared to support shared FortiGate configuration for all ASGs on variable asgs on each example;
* Update doc;

Changes:
* Add variable fgt_config_shared on asg examples;
* Change variable name from fortiflex_sn to fortiflex_token on module/fortigate/fgt;

## Build 0043
Improvements:
* Adjust user config position to avoid reboot;

## Build 0042
Improvements:
* Support primary instance scale-in protection; 
* Improve lambda function to check and clean up the terminated instances that did not trigger the terminate event;

Changes:
* Add variable primary_scalein_protection on module fgt_asg;

## Build 0041
Improvements:
* Support UMS features by adding FortiManager infomations on the boot config of FortiGate instance;

Changes:
Add variable fmg_integration on module fgt_asg;

## Build 0036
Improvements:
* Add route table of nat gateway to IGW when fgt_access_internet_mode set to 'nat_gw';
* Fix 'known after apply' issue when generate route table of fgt login subnet to nat gateway when fgt_access_internet_mode set to 'nat_gw';
* Fix 'true and false result expressions must have consistent type' issue when generate the nat gateway configuration;

Changes:
* Change example name fgt_only to fgt_standalone;
* Add variable mgmt_intf on network_interfaces;
* On fgt-userdata.tftpl of module fortigate/fgt_asg, set defaultgw to enable for interfaces if enable_public_ip are enabled or the interface is mgmt interface;


## Build 0035
Improvements:
* Fix validation issue of variable existing_ngws;
* Fix route table false created when fgt_access_internet_mode not set to eip;


## Build 0034
Improvements:
* Add option of no_eip for variable fgt_access_internet_mode for all examples; 
* Add output of availability_zone on module nat_gateway;

Changes:
* Change variable name from 'existing_ngw' to 'existing_ngws', and change the type to list of map;


## Build 0033
Improvements:
* Support creating GWLB endpoints under spoke vpc for example spk_tgw_gwlb_asg_fgt_igw;

Changes:
* Add option of 'gwlbe_subnet_ids' under spk_vpc;
* Remove options 'private_ips' and 'existing_eip_id' for extra_network_interfaces under variable 'asgs';


## Build 0032
Improvements:
* Update doc;
* Support option of not assign public IP for all FortiGate instance;
* Support create extra interfaces for FortiGate instance;

Changes:
* Add variable of 'fgt_access_internet_mode' on all examples;
* Add option of 'extra_network_interfaces' under variable 'asgs' on all examples;
* Add variable of 'existing_ngw' on module 'spk_tgw_gwlb_asg_fgt_igw' and 'spk_gwlb_asg_fgt_gwlb_igw';
* Add variable of 'mgmt_intf_index' on module 'fgt_asg';
* Add output of 'gwlb_endps' to output the GWLB's endpoints information on all examples;


## Build 0031
Improvements:
* Add module fgt;
* Add example fgt_only;
* Add module of ubuntu_vm in internal_test;


## Build 0023
Improvements:
* Fix issue of variable value known after apply of example spk_tgw_gwlb_asg_fgt_gwlb_igw; 
* Fix Cloudwatch alarm name issue;
* Avoid using Fortiflex token with ACTIVE status and already used;


## Build 0021
Improvements:
* Support private link for DynamoDB by VPC endpoint; 
* Add module prefix to avoid conflict when apply multiple times;

Changes:
* Add variable of 'module_prefix';
* Add variable of 'existing_security_groups';
* Add variable of 'enable_privatelink_dydb';
* Add variable of 'privatelink_security_groups';


## Build 0012
Improvements:
* Fix issue of get federal image of FOS; 
* Update upload fortiflex token to make the token in the data field; 
* Update doc of example spk_gwlb_asg_fgt_wlb_igw; 
* Add variable ami_id to support user providing FOS AMI ID;


## Build 0010
Improvements:
* Configure login port; 
* Fix issue of subnets changes when using existing resources; 
* Set general_tags not required; 
* Add description of name format of variable subnets;


## Build 0009
Improvements:
* Support FortiFlex API username/password;
* Stop FortiFlex SN when the target instance been terminated;
* Support using existing NGW;
* Support using existing resources on all examples;

Changes:
* Add variable of 'fortiflex_username';
* Add variable of 'fortiflex_password';
* Add variable of 'existing_ngw';


## Build 0008

On template spk_tgw_gwlb_asg_fgt_igw:

    Improvements:
    * Support using given CIDR block to generate subnets; (Variable 'subnet_cidr_block')
    * Support not generate subnet for GWLB or TGW if they are marked as ignore. (Ignore it means setting variable 'existing_gwlb' or 'existing_tgw' to empty map);
    * Support using existing subnets; (Variable 'existing_subnets');
    * Change default instance type of FGT instance to 'c5n.xlarge';
    * Support using existing GWLB;
    * Fix validation check error of variable 'security_vpc_tgw_attachments';

    Changes:
    * Add variable of 'existing_subnets';
    * Add variable of 'gwlb_ep_service_name';
    * Add variable of 'existing_gwlb';
    * Add variable of 'existing_gwlb_tgp';
    * Add variable of 'existing_gwlb_ep_service';

On module aws/gwlb:

    Improvements:
    * Support using existing GWLB, GWLB Target Group, VPC Endpoint Service;

    Changes:
    * Add variable of 'existing_gwlb';
    * Add variable of 'existing_gwlb_tgp';
    * Add variable of 'existing_gwlb_ep_service';

On module aws/vpc:

    Changes:
    * Change output of 'subnets' map value from subnet_id to map with keys 'id' and 'availability_zone';
    * Change output of 'igw' from IGW ID to IGW resource output;

On internal_test of template_as_module/spk_tgw_gwlb_asg_fgt_igw/main_existing_vpc.tf.txt:

    Changes:
    * Change example of variable 'subnets' to 'existing_subnets';


## Build 0007

On template spk_tgw_gwlb_asg_fgt_igw:

    Improvements:
    * Support using existing IGW, TGW, VPC;
    * Support ignore TGW and related route tables;
    * Add some validation check functionalities;
    * Support using ENV variables for AWS credentials;

    Changes:
    * Add variable of 'existing_igw';
    * Add variable of 'subnet_cidr_block';

On module aws/vpc:

    Improvements:
    * Support using existing IGW;

    Changes:
    * Add variable of 'existing_igw';

## Build 0006
Improvements:
* Updated the user_conf example;
* Included all rfc1918 spaces on .conf file;
* Add name 'tgw_rt_spokevpc' for Spoke VPC TGW route table;
* Add name for FortiGate instances as the ASG name;
* Support using existing TGW by adding variable 'existing_tgw' on templates;

Changes:
* Change variable 'user_conf' to 'user_conf_content';
* Geneve tunnel name changed from the AZ name to format of geneve-az\<az number\>;

## Build 0005
Improvements:
* Fix lumbda function issue on build 0004

## Build 0004
Improvements:
* Encode password on HTTP request; 
* Set appliance_mode_support default to enable;
* Fix TGWa plan issue; 
* Support ease-west traffic by adding another TGW RT, add variable enable_east_west_inspection;
* Support using private link when communicating with FortiGate instance; 
* Support 1-arm and 2-arm FortiGate interface design by adding variable fgt_intf_mode; 
* Apply general_tags to all resources;
* Support variable user_conf_file_path; 
* Add tag 'Autoscale Role' for FortiGate instance to show its autoscale role;

Changes:
* Update example .tfvars file to remind user must-check variables;
* FortiGate configuration example change to using route policies;

## Build 0003
Improvements:
* Support FortiFlex on FortiGate ASG;
* Add option 'fgt_hostname' into variable 'asgs' on all templates;

## Build 0002
Improvements:
* Support FGT configuration file from S3 by adding variable 'user_conf_s3';
* Support hybrid license FortiGate ASG for all templates;
* Improve .tftpl file to ignore the command line if not configured;
* Update deprecated variable 'vpc' to 'domain' of resource aws_eip;

Changes:
* Delete all Auto Scale Group related variables and combine them into one variable 'asgs' for all templates. So that user could define multiple ASGs;
* Delete template 'spk_tgw_gwlb_hybrid_asg_fgt_igw' since template 'spk_tgw_gwlb_asg_fgt_igw' already covered it;
* Change option type 'alarm_asg_policies' of variable 'cloudwatch_alarms' from list to map for all templates. So that user has more flexibility to configure the auto-scale policies;
* Add new variable 'create_dynamodb_table' for module fgt_asg to determine whether to create the DynamoDB by the module;
